package com.olbnar.smarteletron.enums;

public enum RoleType {
    ROLE_ADMIN,
    ROLE_MANAGER,
    ROLE_STORE,
    ROLE_SALLER,
    ROLE_WARHOUSE
}
