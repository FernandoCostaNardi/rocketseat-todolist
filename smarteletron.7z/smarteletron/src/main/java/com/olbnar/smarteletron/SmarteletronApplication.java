package com.olbnar.smarteletron;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmarteletronApplication {

    public static void main(String[] args) {
        SpringApplication.run(SmarteletronApplication.class, args);
    }

}
