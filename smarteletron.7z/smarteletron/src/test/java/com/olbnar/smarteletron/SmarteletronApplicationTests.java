package com.olbnar.smarteletron;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmarteletronApplicationTests {

    @Test
    void contextLoads() {
    }

}
