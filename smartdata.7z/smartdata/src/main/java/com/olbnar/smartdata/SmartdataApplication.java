package com.olbnar.smartdata;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartdataApplication {

    public static void main(String[] args) {
        SpringApplication.run(SmartdataApplication.class, args);
    }

}
